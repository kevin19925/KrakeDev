let votosMinecraft=0;
let votosRoblox=0;

sumarLikeMinecraft=function(){
    
}
sumarCorazonMinecraft=function(){
  
}
restarLikeMinecraft=function(){
  
}
sumarLikeRoblox=function(){
   
}
sumarCorazonRoblox=function(){
   
}
restarLikeRoblox=function(){
  
}